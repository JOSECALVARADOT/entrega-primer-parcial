const API_KEY = '088cfe5fb4a199d598d6989845828ccb';
const spinner = document.getElementById('spinner');
const weatherContainer = document.querySelector('.weather-container');
const errorDiv = document.getElementById('error');

const cityEl = document.getElementById('city');
const iconEl = document.getElementById('icon');
const descEl = document.getElementById('description');
const tempEl = document.getElementById('temp');
const feelsEl = document.getElementById('feels');
const humidityEl = document.getElementById('humidity');
const windEl = document.getElementById('wind');

const cityInput = document.getElementById('cityInput');
const searchBtn = document.getElementById('searchBtn');
const citySearchDiv = document.querySelector('.city-search');

function getWeather(lat, lon) {
  spinner.classList.remove('hidden');
  fetch(`https://api.openweathermap.org/data/3.0/weather?lat=${lat}&lon=${lon}&appid=${API_KEY}&units=metric&lang=es`)
    .then(res => res.json())
    .then(data => displayWeather(data))
    .catch(err => showError('No se pudo obtener el clima.'))
    .finally(() => spinner.classList.add('hidden'));
}

function getWeatherByCity(city) {
  spinner.classList.remove('hidden');
  fetch(`https://api.openweathermap.org/data/3.0/weather?q=${city}&appid=${API_KEY}&units=metric&lang=es`)
    .then(res => res.json())
    .then(data => displayWeather(data))
    .catch(err => showError('Ciudad no encontrada.'))
    .finally(() => spinner.classList.add('hidden'));
}

function displayWeather(data) {
  if(data.cod && data.cod !== 200){
    showError(data.message);
    return;
  }

  cityEl.textContent = data.name;
  descEl.textContent = data.weather[0].description;
  tempEl.textContent = Math.round(data.main.temp);
  feelsEl.textContent = Math.round(data.main.feels_like);
  humidityEl.textContent = data.main.humidity;
  windEl.textContent = data.wind.speed;

  setWeatherIcon(data.weather[0].main);
  setBackground(data.weather[0].main);

  weatherContainer.classList.remove('hidden');
  citySearchDiv.classList.remove('hidden');
}

function setWeatherIcon(main) {
  switch(main.toLowerCase()) {
    case 'clear': iconEl.textContent = '☀️'; break;
    case 'rain': iconEl.textContent = '🌧️'; break;
    case 'clouds': iconEl.textContent = '☁️'; break;
    case 'snow': iconEl.textContent = '❄️'; break;
    default: iconEl.textContent = '🌡️';
  }
}

function setBackground(main) {
  document.body.className = '';
  switch(main.toLowerCase()) {
    case 'clear': document.body.classList.add('sunny'); break;
    case 'rain': document.body.classList.add('rainy'); break;
    case 'clouds': document.body.classList.add('cloudy'); break;
    case 'snow': document.body.classList.add('snowy'); break;
    default: document.body.style.background = '#eee';
  }
}

function showError(msg) {
  errorDiv.textContent = msg;
  errorDiv.classList.remove('hidden');
}

if(navigator.geolocation){
  navigator.geolocation.getCurrentPosition(
    position => {
      const {latitude, longitude} = position.coords;
      getWeather(latitude, longitude);
    },
    error => {
      showError('Permiso de geolocalización denegado.');
      citySearchDiv.classList.remove('hidden');
    }
  );
} else {
  showError('Geolocalización no soportada.');
  citySearchDiv.classList.remove('hidden');
}

searchBtn.addEventListener('click', () => {
  const city = cityInput.value.trim();
  if(city) getWeatherByCity(city);
});
