/* script.js
   Comentarios: Validación en tiempo real, manejo del modal, y animación de confeti.
*/

document.addEventListener('DOMContentLoaded', () => {
  // Elementos del formulario y modal
  const form = document.getElementById('contactForm');
  const nameInput = document.getElementById('name');
  const emailInput = document.getElementById('email');
  const messageInput = document.getElementById('message');
  const nameError = document.getElementById('nameError');
  const emailError = document.getElementById('emailError');
  const messageError = document.getElementById('messageError');
  const modal = document.getElementById('modal');
  const closeModalBtn = document.getElementById('closeModal');
  const subscribeBtn = document.getElementById('subscribeBtn');
  const confettiLayer = document.getElementById('confettiLayer');

  // Regex simple para validar email (cliente). No reemplaza validación en servidor.
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  // Funciones de validación por campo
  function validateName(){
    const value = nameInput.value.trim();
    if(!value){ nameError.textContent = 'El nombre es obligatorio.'; return false; }
    nameError.textContent = '';
    return true;
  }

  function validateEmail(){
    const value = emailInput.value.trim();
    if(!value){ emailError.textContent = 'El correo es obligatorio.'; return false; }
    if(!emailRegex.test(value)){ emailError.textContent = 'Formato de correo inválido.'; return false; }
    emailError.textContent = '';
    return true;
  }

  function validateMessage(){
    const value = messageInput.value.trim();
    if(!value){ messageError.textContent = 'Escribe un mensaje.'; return false; }
    if(value.length < 6){ messageError.textContent = 'El mensaje es muy corto.'; return false; }
    messageError.textContent = '';
    return true;
  }

  // Validación en tiempo real (input / blur)
  nameInput.addEventListener('input', validateName);
  emailInput.addEventListener('input', validateEmail);
  messageInput.addEventListener('input', validateMessage);

  // Manejo del envío: validar, mostrar modal y confeti
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const ok = validateName() & validateEmail() & validateMessage();
    if(ok){
      // Simulamos envío y mostramos modal
      showModal();
    }
  });

  // Suscribe button también abre modal + confeti (ejemplo del requisito)
  subscribeBtn.addEventListener('click', showModal);

  closeModalBtn.addEventListener('click', hideModal);

  // Mostrar modal accesible
  function showModal(){
    modal.setAttribute('aria-hidden', 'false');
    // Generar confeti (10-15 piezas)
    generateConfetti(12);
    // Cerrar modal con Escape
    document.addEventListener('keydown', escHandler);
  }

  function hideModal(){
    modal.setAttribute('aria-hidden', 'true');
    // limpiar confeti luego de animación
    setTimeout(()=> confettiLayer.innerHTML = '', 1200);
    document.removeEventListener('keydown', escHandler);
  }

  function escHandler(e){
    if(e.key === 'Escape') hideModal();
  }

  // Generador de confeti simple: crea elementos DOM con animación CSS
  function generateConfetti(amount = 12){
    const colors = ['#FE6B8B','#FFD166','#06D6A0','#4D96FF','#9B5DE5','#FFB4A2'];
    const width = window.innerWidth;
    for(let i=0;i<amount;i++){
      const piece = document.createElement('div');
      piece.className = 'confetti';
      // Posición horizontal aleatoria
      piece.style.left = Math.random() * width + 'px';
      // Delay y duration aleatorios para naturalidad
      const delay = Math.random() * 0.3;
      const dur = 0.9 + Math.random() * 1.2;
      piece.style.animationDuration = dur + 's';
      piece.style.animationDelay = delay + 's';
      // Color y tamaño aleatorio
      piece.style.background = colors[Math.floor(Math.random()*colors.length)];
      piece.style.width = (6 + Math.random()*10) + 'px';
      piece.style.height = (10 + Math.random()*10) + 'px';
      // Añadir rotación inicial
      piece.style.transform = 'translateY(-10vh) rotate(' + (Math.random()*360) + 'deg)';
      confettiLayer.appendChild(piece);
    }
  }
});
