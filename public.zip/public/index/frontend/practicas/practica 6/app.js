// app.js
// Juego de memoria con flores 🌸
// - 12 cartas (6 parejas)
// - Límite de tiempo: 10 minutos
// - Contador de intentos y temporizador
// - Mensaje de victoria o fin de tiempo

const board = document.getElementById("board");
const attemptsEl = document.getElementById("attempts");
const timerEl = document.getElementById("timer");
const overlay = document.getElementById("overlay");
const overlayTitle = document.getElementById("overlayTitle");
const overlayText = document.getElementById("overlayText");
const restartBtn = document.getElementById("restartBtn");
const playAgainBtn = document.getElementById("playAgain");

// Emojis de flores (6 parejas)
const flowers = ["🌹","🌻","🌼","🌷","🥀","🌸"];
let cards = [];
let flippedCards = [];
let matchedCount = 0;
let attempts = 0;
let timer;
let timeLeft = 600; // 10 minutos en segundos
let gameStarted = false;

// Inicializar el juego
function initGame(){
  // Reiniciar variables
  board.innerHTML = "";
  attempts = 0;
  attemptsEl.textContent = "Intentos: 0";
  flippedCards = [];
  matchedCount = 0;
  timeLeft = 600;
  gameStarted = false;
  updateTimer();

  // Crear y mezclar cartas
  cards = [...flowers, ...flowers]
    .sort(() => Math.random() - 0.5);

  cards.forEach(flower=>{
    const card = document.createElement("div");
    card.classList.add("card");
    card.dataset.value = flower;
    card.innerHTML = `
      <div class="card-inner">
        <div class="card-front">${flower}</div>
        <div class="card-back">❀</div>
      </div>`;
    card.addEventListener("click", ()=>flipCard(card));
    board.appendChild(card);
  });
}

// Voltear carta
function flipCard(card){
  if(card.classList.contains("flipped") || card.classList.contains("matched")) return;
  if(flippedCards.length === 2) return;

  card.classList.add("flipped");
  flippedCards.push(card);

  // Iniciar temporizador en primer clic
  if(!gameStarted){
    gameStarted = true;
    startTimer();
  }

  if(flippedCards.length === 2){
    attempts++;
    attemptsEl.textContent = `Intentos: ${attempts}`;
    checkMatch();
  }
}

// Verificar pareja
function checkMatch(){
  const [c1, c2] = flippedCards;
  if(c1.dataset.value === c2.dataset.value){
    c1.classList.add("matched");
    c2.classList.add("matched");
    matchedCount++;
    flippedCards = [];

    if(matchedCount === flowers.length){
      endGame(true);
    }
  } else {
    setTimeout(()=>{
      c1.classList.remove("flipped");
      c2.classList.remove("flipped");
      flippedCards = [];
    },1000);
  }
}

// Iniciar temporizador
function startTimer(){
  timer = setInterval(()=>{
    timeLeft--;
    updateTimer();
    if(timeLeft <= 0){
      clearInterval(timer);
      endGame(false);
    }
  },1000);
}

// Actualizar pantalla del tiempo
function updateTimer(){
  const m = String(Math.floor(timeLeft/60)).padStart(2,"0");
  const s = String(timeLeft%60).padStart(2,"0");
  timerEl.textContent = `Tiempo: ${m}:${s}`;
}

// Terminar juego
function endGame(won){
  clearInterval(timer);
  overlay.classList.add("active");
  if(won){
    overlayTitle.textContent = "¡Felicidades!";
    overlayText.textContent = `Ganaste en ${attempts} intentos y ${formatTime(600-timeLeft)}.`;
  } else {
    overlayTitle.textContent = "⏰ Tiempo agotado";
    overlayText.textContent = "No lograste completar el juego en 10 minutos.";
  }
}

// Formatear tiempo transcurrido
function formatTime(sec){
  const m = String(Math.floor(sec/60)).padStart(2,"0");
  const s = String(sec%60).padStart(2,"0");
  return `${m}:${s}`;
}

// Eventos de reinicio
restartBtn.addEventListener("click", ()=>{
  clearInterval(timer);
  overlay.classList.remove("active");
  initGame();
});
playAgainBtn.addEventListener("click", ()=>{
  clearInterval(timer);
  overlay.classList.remove("active");
  initGame();
});

// Iniciar primera vez
initGame();
