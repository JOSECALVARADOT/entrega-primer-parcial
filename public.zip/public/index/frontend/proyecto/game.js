const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");
let dpr = window.devicePixelRatio || 1;

function fitCanvas() {
  const cssW = canvas.clientWidth || 800;
  const cssH = canvas.clientHeight || 360;
  canvas.width = Math.floor(cssW * dpr);
  canvas.height = Math.floor(cssH * dpr);
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
}
fitCanvas();
window.addEventListener("resize", () => { dpr = window.devicePixelRatio || 1; fitCanvas(); });

let player = { x: 50, y: 300, width: 40, height: 40, dy: 0, jumpPower: -12, gravity: 0.7, grounded: false };
let playerSymbol = "☠";
let playerFontSize = 38;
let obstacles = [];
let score = 0;
let gameOver = false;
let baseSpeed = 6;
let speed = baseSpeed;
let leaderboard = JSON.parse(localStorage.getItem("leaderboard")) || [];
let frame = 0;

let lastObstacleFrame = 0;
let minGapInit = 140;
let maxGapInit = 220;
let minGap = minGapInit;
let maxGap = maxGapInit;
let nextObstacleGap = Math.floor(Math.random() * (maxGap - minGap)) + minGap;

function levelFromScore() {
  return Math.max(1, Math.floor(score / 10) + 1);
}

function applyDifficulty() {
  const lvl = levelFromScore();
  speed = baseSpeed + (lvl - 1) * 0.9 + Math.floor(score / 20) * 0.25;
  minGap = Math.max(40, Math.floor(minGapInit - (lvl - 1) * 8));
  maxGap = Math.max(minGap + 30, Math.floor(maxGapInit - (lvl - 1) * 8));
}

function drawBackground() {
  const g = ctx.createLinearGradient(0, 0, 0, canvas.height / dpr);
  g.addColorStop(0, "#08060b");
  g.addColorStop(0.5, "#0d0b10");
  g.addColorStop(1, "#040204");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, canvas.width / dpr, canvas.height / dpr);
  const moonX = (canvas.width / dpr) - ((frame / 80) % (canvas.width / dpr + 200));
  const moonY = 80 + Math.sin(frame / 200) * 20;
  ctx.beginPath();
  ctx.arc(moonX, moonY, 28, 0, Math.PI * 2);
  ctx.fillStyle = "#f6f6ff";
  ctx.fill();
}

function drawPlayer() {
  ctx.fillStyle = "#c4b998";
  ctx.font = `${playerFontSize}px UnifrakturCook, serif`;
  ctx.textBaseline = "alphabetic";
  ctx.fillText(playerSymbol, player.x, player.y + player.height);
}

function drawObstacles() {
  ctx.fillStyle = "#d8c9c0";
  obstacles.forEach(o => {
    ctx.font = `${o.fontSize}px UnifrakturCook, serif`;
    ctx.textBaseline = "alphabetic";
    ctx.fillText(o.symbol, o.x, o.y);
  });
}

function drawHUD() {
  ctx.fillStyle = "#efe7dc";
  ctx.font = "18px Cinzel, serif";
  ctx.fillText("Puntos: " + score, 12, 28);
  ctx.fillText("Nivel: " + levelFromScore(), 12, 54);
  ctx.fillText("Vel: " + speed.toFixed(2), 12, 78);
}

function makeObstacle(xOffset) {
  const gothic = ["🪦", "☠️", "✝️", "🩸"];
  const pick = gothic[Math.floor(Math.random() * gothic.length)];
  const fontSize = 28 + Math.floor(Math.random() * 16);
  const baselineY = (canvas.height / dpr) - 10;
  const xStart = (canvas.width / dpr) + 30 + (xOffset || 0);
  const o = { x: xStart, y: baselineY, symbol: pick, fontSize };
  ctx.font = `${o.fontSize}px UnifrakturCook, serif`;
  const metrics = ctx.measureText(o.symbol);
  const w = Math.max(metrics.width, o.fontSize * 0.8);
  const h = o.fontSize;
  o.rawW = w;
  o.rawH = h;
  const shrink = 0.72;
  o.w = w * shrink;
  o.h = h * shrink;
  o.hitOffsetX = (w - o.w) / 2;
  o.hitOffsetY = (h - o.h) / 2;
  return o;
}

function spawnObstacle(xOffset) {
  obstacles.push(makeObstacle(xOffset));
}

function updatePlayer() {
  if (!player.grounded) player.dy += player.gravity;
  player.y += player.dy;
  if (player.y + player.height >= (canvas.height / dpr)) {
    player.y = (canvas.height / dpr) - player.height;
    player.dy = 0;
    player.grounded = true;
  } else {
    player.grounded = false;
  }
}

function updateObstacles() {
  obstacles.forEach(o => o.x -= speed);
  while (obstacles.length && obstacles[0].x < -200) {
    obstacles.shift();
    score++;
    applyDifficulty();
  }
  if (frame - lastObstacleFrame > nextObstacleGap) {
    const lvl = levelFromScore();
    const extraChance = Math.min(0.6, 0.08 + (lvl - 1) * 0.06 + score / 1000);
    const clusterSize = 1 + Math.floor((lvl - 1) / 5);
    const spacingBetweenCluster = Math.max(40, Math.floor(120 - lvl * 6));
    for (let i = 0; i < clusterSize; i++) {
      if (i === 0) spawnObstacle(0);
      else if (Math.random() < extraChance) spawnObstacle(i * spacingBetweenCluster);
    }
    if (Math.random() < extraChance) {
      const tailChance = Math.random();
      if (tailChance < 0.5) spawnObstacle(spacingBetweenCluster * (clusterSize + 1));
    }
    lastObstacleFrame = frame;
    nextObstacleGap = Math.floor(Math.random() * (maxGap - minGap)) + minGap;
  }
}

function rectsIntersect(a, b) {
  return a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;
}

function detectCollision() {
  const playerDrawW = Math.max(ctx.measureText(playerSymbol).width, playerFontSize * 0.8);
  const shrinkPlayer = 0.68;
  const pW = playerDrawW * shrinkPlayer;
  const pH = playerFontSize * shrinkPlayer;
  const pOffsetX = (player.width - pW) / 2;
  const pOffsetY = (player.height - pH) / 2;
  const playerRect = { x: player.x + pOffsetX, y: player.y + pOffsetY, w: pW, h: pH };
  for (let i = 0; i < obstacles.length; i++) {
    const o = obstacles[i];
    const obRect = {
      x: o.x + o.hitOffsetX,
      y: o.y - o.rawH + o.hitOffsetY,
      w: o.w,
      h: o.h
    };
    if (rectsIntersect(playerRect, obRect)) {
      gameOver = true;
      const go = document.getElementById("gameOver");
      if (go) go.classList.remove("hidden");
      break;
    }
  }
}

function gameLoop() {
  if (gameOver) return;
  frame++;
  drawBackground();
  updatePlayer();
  updateObstacles();
  detectCollision();
  drawPlayer();
  drawObstacles();
  drawHUD();
  requestAnimationFrame(gameLoop);
}

document.addEventListener("keydown", e => {
  if (e.code === "Space" && player.grounded) {
    player.dy = player.jumpPower;
    player.grounded = false;
  }
});

const restartBtn = document.getElementById("restartBtn") || document.getElementById("restart");
if (restartBtn) restartBtn.addEventListener("click", () => {
  player.y = (canvas.height / dpr) - player.height;
  player.dy = 0;
  obstacles = [];
  score = 0;
  gameOver = false;
  const go = document.getElementById("gameOver");
  if (go) go.classList.add("hidden");
  fitCanvas();
  frame = 0;
  lastObstacleFrame = 0;
  minGap = minGapInit;
  maxGap = maxGapInit;
  nextObstacleGap = Math.floor(Math.random() * (maxGap - minGap)) + minGap;
  speed = baseSpeed;
  requestAnimationFrame(gameLoop);
});

const saveBtn = document.getElementById("saveScoreBtn") || document.getElementById("saveScore");
if (saveBtn) saveBtn.addEventListener("click", () => {
  const nameEl = document.getElementById("playerName");
  const name = nameEl ? (nameEl.value || "Anónimo") : "Anónimo";
  leaderboard.push({ name, score });
  leaderboard.sort((a, b) => b.score - a.score);
  leaderboard = leaderboard.slice(0, 10);
  localStorage.setItem("leaderboard", JSON.stringify(leaderboard));
  renderLeaderboard();
});

function renderLeaderboard() {
  const ul = document.getElementById("leaderboard");
  if (!ul) return;
  ul.innerHTML = "";
  leaderboard.forEach(e => {
    const li = document.createElement("li");
    li.textContent = `${e.name} — ${e.score} ☠`;
    ul.appendChild(li);
  });
}

renderLeaderboard();
applyDifficulty();
requestAnimationFrame(gameLoop);
